--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cpp_restaurant;
--
-- Name: cpp_restaurant; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cpp_restaurant WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE cpp_restaurant OWNER TO postgres;

\connect cpp_restaurant

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    name character varying NOT NULL,
    dob date NOT NULL,
    phone bigint NOT NULL,
    address character varying NOT NULL,
    "broncoID" integer NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: financialreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financialreport (
    "reportID" integer NOT NULL,
    "startDate" date NOT NULL,
    "endDate" date NOT NULL
);


ALTER TABLE public.financialreport OWNER TO postgres;

--
-- Name: fooditem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fooditem (
    "itemID" integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.fooditem OWNER TO postgres;

--
-- Name: fooditem_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fooditem_order (
    "itemID" integer NOT NULL,
    "orderID" integer NOT NULL
);


ALTER TABLE public.fooditem_order OWNER TO postgres;

--
-- Name: fooditem_shoppingcart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fooditem_shoppingcart (
    "cartID" integer NOT NULL,
    "itemID" integer NOT NULL
);


ALTER TABLE public.fooditem_shoppingcart OWNER TO postgres;

--
-- Name: fooditem_staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fooditem_staff (
    "staffID" integer NOT NULL,
    "itemID" integer NOT NULL
);


ALTER TABLE public.fooditem_staff OWNER TO postgres;

--
-- Name: order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."order" (
    "OrderID" integer NOT NULL,
    "broncoID" integer NOT NULL,
    status integer NOT NULL,
    date date NOT NULL
);


ALTER TABLE public."order" OWNER TO postgres;

--
-- Name: order_financialreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_financialreport (
    "reportID" integer NOT NULL,
    "orderID" integer NOT NULL
);


ALTER TABLE public.order_financialreport OWNER TO postgres;

--
-- Name: price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price (
    "priceID" integer NOT NULL,
    date date NOT NULL,
    price real NOT NULL,
    "itemID" integer NOT NULL
);


ALTER TABLE public.price OWNER TO postgres;

--
-- Name: professor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professor (
    "broncoID" integer NOT NULL,
    dateofbirth date NOT NULL,
    phone bigint NOT NULL,
    address character varying NOT NULL,
    department character varying NOT NULL,
    office character varying NOT NULL,
    research character varying NOT NULL
);


ALTER TABLE public.professor OWNER TO postgres;

--
-- Name: receipt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipt (
    "receiptID" integer NOT NULL,
    total money NOT NULL
);


ALTER TABLE public.receipt OWNER TO postgres;

--
-- Name: receipt_financialreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipt_financialreport (
    "reportID" integer NOT NULL,
    "receiptID" integer NOT NULL
);


ALTER TABLE public.receipt_financialreport OWNER TO postgres;

--
-- Name: shoppingcart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shoppingcart (
    "cartID" integer NOT NULL,
    "broncoID" integer NOT NULL
);


ALTER TABLE public.shoppingcart OWNER TO postgres;

--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    "staffID" integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    "broncoID" integer NOT NULL,
    name character varying NOT NULL,
    major character varying NOT NULL,
    minor character varying NOT NULL,
    address character varying NOT NULL,
    dateofbirth date NOT NULL,
    phone bigint NOT NULL,
    profession character varying NOT NULL,
    "graduationDate" date NOT NULL,
    "enterDate" date
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (name, dob, phone, address, "broncoID") FROM stdin;
\.
COPY public.customer (name, dob, phone, address, "broncoID") FROM '$$PATH$$/3393.dat';

--
-- Data for Name: financialreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financialreport ("reportID", "startDate", "endDate") FROM stdin;
\.
COPY public.financialreport ("reportID", "startDate", "endDate") FROM '$$PATH$$/3380.dat';

--
-- Data for Name: fooditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fooditem ("itemID", name) FROM stdin;
\.
COPY public.fooditem ("itemID", name) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: fooditem_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fooditem_order ("itemID", "orderID") FROM stdin;
\.
COPY public.fooditem_order ("itemID", "orderID") FROM '$$PATH$$/3382.dat';

--
-- Data for Name: fooditem_shoppingcart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fooditem_shoppingcart ("cartID", "itemID") FROM stdin;
\.
COPY public.fooditem_shoppingcart ("cartID", "itemID") FROM '$$PATH$$/3383.dat';

--
-- Data for Name: fooditem_staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fooditem_staff ("staffID", "itemID") FROM stdin;
\.
COPY public.fooditem_staff ("staffID", "itemID") FROM '$$PATH$$/3384.dat';

--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."order" ("OrderID", "broncoID", status, date) FROM stdin;
\.
COPY public."order" ("OrderID", "broncoID", status, date) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: order_financialreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_financialreport ("reportID", "orderID") FROM stdin;
\.
COPY public.order_financialreport ("reportID", "orderID") FROM '$$PATH$$/3386.dat';

--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price ("priceID", date, price, "itemID") FROM stdin;
\.
COPY public.price ("priceID", date, price, "itemID") FROM '$$PATH$$/3387.dat';

--
-- Data for Name: professor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professor ("broncoID", dateofbirth, phone, address, department, office, research) FROM stdin;
\.
COPY public.professor ("broncoID", dateofbirth, phone, address, department, office, research) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: receipt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipt ("receiptID", total) FROM stdin;
\.
COPY public.receipt ("receiptID", total) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: receipt_financialreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipt_financialreport ("reportID", "receiptID") FROM stdin;
\.
COPY public.receipt_financialreport ("reportID", "receiptID") FROM '$$PATH$$/3389.dat';

--
-- Data for Name: shoppingcart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shoppingcart ("cartID", "broncoID") FROM stdin;
\.
COPY public.shoppingcart ("cartID", "broncoID") FROM '$$PATH$$/3390.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff ("staffID", name) FROM stdin;
\.
COPY public.staff ("staffID", name) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student ("broncoID", name, major, minor, address, dateofbirth, phone, profession, "graduationDate", "enterDate") FROM stdin;
\.
COPY public.student ("broncoID", name, major, minor, address, dateofbirth, phone, profession, "graduationDate", "enterDate") FROM '$$PATH$$/3379.dat';

--
-- Name: student Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY ("broncoID");


--
-- Name: financialreport FinancialReport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financialreport
    ADD CONSTRAINT "FinancialReport_pkey" PRIMARY KEY ("reportID");


--
-- Name: fooditem FoodItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fooditem
    ADD CONSTRAINT "FoodItem_pkey" PRIMARY KEY ("itemID");


--
-- Name: order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY ("OrderID");


--
-- Name: price Price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT "Price_pkey" PRIMARY KEY ("priceID");


--
-- Name: receipt Receipt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt
    ADD CONSTRAINT "Receipt_pkey" PRIMARY KEY ("receiptID");


--
-- Name: shoppingcart ShoppingCart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shoppingcart
    ADD CONSTRAINT "ShoppingCart_pkey" PRIMARY KEY ("cartID");


--
-- Name: staff Staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT "Staff_pkey" PRIMARY KEY ("staffID");


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY ("broncoID");


--
-- Name: professor professor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_pkey PRIMARY KEY ("broncoID");


--
-- Name: price itemID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT "itemID" FOREIGN KEY ("itemID") REFERENCES public.fooditem("itemID") NOT VALID;


--
-- PostgreSQL database dump complete
--

